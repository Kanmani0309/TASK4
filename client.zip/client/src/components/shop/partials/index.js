import Navber from "./Navber";
import Footer from "./Footer";
import CartModal from "./CartModal";

export { Navber, Footer, CartModal };
